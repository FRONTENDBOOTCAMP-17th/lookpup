import { NextResponse } from "next/server";
import { createClient } from "@/utils/supabase/server";
import { createServiceClient } from "@/utils/supabase/service";

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");

  if (code) {
    const supabase = await createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);

    if (!error) {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (user) {
        const { data: existingUser } = await createServiceClient().from("users").select("is_verified").eq("id", user.id).is("deleted_at", null).maybeSingle();

        if (existingUser?.is_verified) return NextResponse.redirect(`${origin}/`);

        return NextResponse.redirect(`${origin}/auth/signup`);
      }
    }
  }

  return NextResponse.redirect(`${origin}/auth/login?error=oauth`);
}
