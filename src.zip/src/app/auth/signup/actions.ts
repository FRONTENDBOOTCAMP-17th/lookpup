"use server";

import { createClient } from "@/utils/supabase/server";
import { createServiceClient } from "@/utils/supabase/service";
import { redirect } from "next/navigation";

interface PortOneVerifiedCustomer {
  name: string;
  gender: string;
  birthDate: string;
  phoneNumber: string;
}

interface PortOneVerificationResult {
  status: string;
  verifiedCustomer?: PortOneVerifiedCustomer;
}

export async function completeSignup(identityVerificationId: string) {
  // 포트원 V2 API로 본인인증 결과 검증
  const portoneRes = await fetch(
    `https://api.portone.io/identity-verifications/${identityVerificationId}`,
    {
      headers: {
        Authorization: `PortOne ${process.env.PORTONE_API_SECRET}`,
      },
      cache: "no-store",
    },
  );

  if (!portoneRes.ok) {
    return { error: "본인인증 결과 조회에 실패했습니다." };
  }

  const verificationData: PortOneVerificationResult = await portoneRes.json();

  if (
    verificationData.status !== "VERIFIED" ||
    !verificationData.verifiedCustomer
  ) {
    return { error: "본인인증이 완료되지 않았습니다." };
  }

  const { name, gender, birthDate, phoneNumber } =
    verificationData.verifiedCustomer;

  // 2. Supabase Auth 세션에서 OAuth 유저 조회 (anon 클라이언트)
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/auth/login");
  }

  // 3~5. DB 작업은 RLS를 우회하는 service role 클라이언트 사용
  const db = createServiceClient();

  //  전화번호 중복 검증 (deleted_at IS NULL 조건)
  const { data: duplicatePhone } = await db
    .from("users")
    .select("id")
    .eq("phone_number", phoneNumber)
    .is("deleted_at", null)
    .maybeSingle();

  if (duplicatePhone) {
    return { error: "이미 가입된 전화번호입니다." };
  }

  // 4. 이메일 중복 검증 (deleted_at IS NULL 조건)
  if (user.email) {
    const { data: duplicateEmail } = await db
      .from("users")
      .select("id")
      .eq("email", user.email)
      .is("deleted_at", null)
      .maybeSingle();

    if (duplicateEmail) {
      return { error: "이미 가입된 이메일입니다." };
    }
  }

  // 5. users 테이블 INSERT
  const provider = user.app_metadata.provider ?? "google";
  const email = user.email ?? "";
  const profileImage =
    user.user_metadata?.avatar_url ?? user.user_metadata?.picture ?? "";

  const { error: insertError } = await db.from("users").insert({
    id: user.id,
    email,
    provider,
    full_name: name,
    birthdate: birthDate,
    phone_number: phoneNumber,
    gender: gender === "FEMALE" ? "FEMALE" : "MALE",
    profile_image: profileImage,
    role: "owner",
    is_verified: true,
  });

  if (insertError) {
    if (insertError.code === "23505") {
      return { error: "이미 가입된 계정입니다." };
    }
    return { error: `[${insertError.code}] ${insertError.message}` };
  }

  redirect("/");
}
